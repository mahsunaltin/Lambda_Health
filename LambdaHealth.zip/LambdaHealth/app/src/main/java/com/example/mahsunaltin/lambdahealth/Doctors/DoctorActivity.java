package com.example.mahsunaltin.lambdahealth.Doctors;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.mahsunaltin.lambdahealth.R;

//Uygulamanin doktor heasbini acan sayfasi
//Yetistirilememistir...

public class DoctorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor);
    }
}
