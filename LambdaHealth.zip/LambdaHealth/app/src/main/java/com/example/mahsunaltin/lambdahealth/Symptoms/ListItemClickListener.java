package com.example.mahsunaltin.lambdahealth.Symptoms;

//Recyclerview elemanlarina tiklandigindaki olaylari yonetebilmek icin kullanilan kod.

public interface ListItemClickListener {
    void onListItemClick(int clickedItemIndex);
}
